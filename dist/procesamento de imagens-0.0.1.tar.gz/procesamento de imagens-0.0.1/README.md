# image_processing

Description.
the package image_processing is used to:
    processing:
        - Histrogram matching
        - Structural Similarity
        - Resize image
    Utils:
        - Read image
        - Save image
        - Plot image
        - Plot result
        - Plot histogram

## instalation
Use the package manager to install the package image_processing

```bash
pip install image_processing
```

## License
[MIT](https://opensource.org/licenses/MIT)

## Author
Murilo Calore
